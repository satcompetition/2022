#ifndef _compact_h_INCLUDED
#define _compact_h_INCLUDED

#include <stdbool.h>

struct simplifier;
void compact_ruler (struct simplifier *, bool preprocessing);

#endif
