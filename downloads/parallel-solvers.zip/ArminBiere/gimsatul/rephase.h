#ifndef _rephase_h_INCLUDED
#define _rephase_h_INCLUDED

#include <stdbool.h>

struct ring;

bool rephasing (struct ring *);
void rephase (struct ring *);

#endif
