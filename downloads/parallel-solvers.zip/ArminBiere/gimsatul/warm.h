#ifndef _warm_h_INCLUDED
#define _warm_h_INCLUDED

struct ring;
void warming_up_saved_phases (struct ring *);

#endif
