#ifndef _detach_h_INCLUDED
#define _detach_h_INCLUDED

struct ruler;

void detach_and_delete_rings (struct ruler *);

#endif
