#ifndef _catch_h_INCLUDED
#define _catch_h_INCLUDED

struct ruler;
void reset_signal_handlers (void);
void set_signal_handlers (struct ruler *);

#endif
