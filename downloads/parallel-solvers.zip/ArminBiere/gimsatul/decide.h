#ifndef _decide_h_INCLUDED
#define _decide_h_INCLUDED

struct ring;

void decide (struct ring *);
signed char initial_phase (struct ring *);

#endif
