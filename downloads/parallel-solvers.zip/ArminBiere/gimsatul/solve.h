#ifndef _solve_h_INCLUDED
#define _solve_h_INCLUDED

struct ring;
struct ruler;

struct ring *solve_rings (struct ruler *);

#endif
