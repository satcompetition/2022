#!/bin/sh
exec ./gimsatul -n -r --threads=32 $*
