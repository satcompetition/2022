# GimSATul Parallel Track SAT Competition on AWS Set-Up

Following the Mallob set-up.

To build use the following:

> `cd base && docker build -t gimsatul-base . && cd ..`

> `cd leader && docker build -t gimsatul-leader . && cd ..`

or just call `make build`.
