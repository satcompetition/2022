#ifndef _unclone_h_INCLUDED
#define _unclone_h_INCLUDED

struct ring;
void unclone_ring (struct ring *ring);

#endif
