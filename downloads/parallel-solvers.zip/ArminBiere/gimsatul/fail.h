#ifndef _failed_h_INCLUDED
#define _failed_h_INCLUDED

struct ring;

void failed_literal_probing (struct ring *);

#endif
