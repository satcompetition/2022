#!/bin/sh
exec /opt/gimsatul/gimsatul --threads=32
