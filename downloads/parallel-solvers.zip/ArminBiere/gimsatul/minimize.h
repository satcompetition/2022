#ifndef _minimize_h_INCLUDED
#define _minimize_h_INCLUDED

struct ring;
void shrink_or_minimize_clause (struct ring *, unsigned glue);

#endif
