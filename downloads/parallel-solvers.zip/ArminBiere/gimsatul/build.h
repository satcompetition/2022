#ifndef _build_h_INCLUDED
#define _build_h_INCLUDED

void print_banner (void);
void print_version (void);

#endif
