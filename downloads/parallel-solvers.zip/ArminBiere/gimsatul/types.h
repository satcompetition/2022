#ifndef _types_h_INCLUDED
#define _types_h_INCLUDED

void check_types (void);

#endif
